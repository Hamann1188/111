Instructions:
 - rename "startworker.rename to bat" file to "startworker.bat"
 - (optionally) edit "startworker.bat" file to change starting options
 - double-click "startworker.bat" file to start the worker