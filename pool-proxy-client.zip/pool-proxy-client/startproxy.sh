#!/bin/sh
java -Xmx1024m -jar pool-client-2.4-0-20190821.jar start poolminer.properties
