
- Install Java 8 or higher
- Edit poolminer.properties and set "pool.illamanudi.payout.address" with your tag or WOTS 
- Run the proxy-client -> java -Xmx1024m -jar pool-client-2.4-0-[version date].jar start poolminer.properties
